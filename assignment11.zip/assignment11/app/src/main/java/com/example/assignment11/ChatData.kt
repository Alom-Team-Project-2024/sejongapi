package com.example.assignment11

data class ChatData(
    val chat:String,
    val viewType:Int
)