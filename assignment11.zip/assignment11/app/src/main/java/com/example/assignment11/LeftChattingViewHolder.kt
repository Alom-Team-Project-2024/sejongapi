package com.example.assignment11

import androidx.recyclerview.widget.RecyclerView
import com.example.assignment11.databinding.LeftchattingSampleBinding

class LeftChattingViewHolder(binding: LeftchattingSampleBinding): RecyclerView.ViewHolder(binding.root){
    val chat=binding.textLeft
}