package com.example.assignment11

import androidx.recyclerview.widget.RecyclerView
import com.example.assignment11.databinding.RightchattingSampleBinding

class RightChattingViewHolder (binding: RightchattingSampleBinding): RecyclerView.ViewHolder(binding.root){
    val chat=binding.textRight
}